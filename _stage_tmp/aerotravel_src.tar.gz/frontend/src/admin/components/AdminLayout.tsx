import { NavLink, Outlet } from 'react-router-dom'
import {
  LayoutDashboard,
  Globe2,
  MapPinned,
  Wrench,
  Tag,
  MessageSquareQuote,
  HelpCircle,
  FileText,
  Inbox,
  ScrollText,
  LogOut,
  Plane,
} from 'lucide-react'
import { useAdminLogout, useAdminSession } from '@/admin/hooks/useAdminAuth'
import { cn } from '@/lib/cn'

interface NavItem {
  to: string
  label: string
  icon: typeof LayoutDashboard
  end?: boolean
}

const NAV: NavItem[] = [
  { to: '/admin', label: 'Дашборд', icon: LayoutDashboard, end: true },
  { to: '/admin/destinations', label: 'Направления', icon: MapPinned },
  { to: '/admin/offers', label: 'Предложения', icon: Tag },
  { to: '/admin/services', label: 'Услуги', icon: Wrench },
  { to: '/admin/countries-cities', label: 'Страны и города', icon: Globe2 },
  { to: '/admin/testimonials', label: 'Отзывы', icon: MessageSquareQuote },
  { to: '/admin/faq', label: 'Вопросы', icon: HelpCircle },
  { to: '/admin/site-content', label: 'Контент сайта', icon: FileText },
  { to: '/admin/travel-requests', label: 'Заявки', icon: Inbox },
  { to: '/admin/audit-log', label: 'Журнал аудита', icon: ScrollText },
]

export function AdminLayout() {
  const { admin } = useAdminSession()
  const logout = useAdminLogout()

  return (
    <div className="flex min-h-screen bg-paper text-ink">
      <aside className="hidden w-64 shrink-0 flex-col border-r border-ink/10 bg-ink text-paper md:flex">
        <div className="flex items-center gap-2 px-6 py-6 font-display text-lg">
          <Plane size={18} className="text-brand-accent" /> AeroTravel
          <span className="ml-auto rounded-full bg-paper/10 px-2 py-0.5 text-[10px] uppercase tracking-wide text-paper/60">Admin</span>
        </div>
        <nav className="flex-1 space-y-1 px-3">
          {NAV.map(({ to, label, icon: Icon, end }) => (
            <NavLink
              key={to}
              to={to}
              end={end}
              className={({ isActive }) =>
                cn(
                  'flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm text-paper/75 transition-colors hover:bg-paper/10 hover:text-paper',
                  isActive && 'bg-paper/10 text-paper',
                )
              }
            >
              <Icon size={16} /> {label}
            </NavLink>
          ))}
        </nav>
        <div className="border-t border-paper/10 px-4 py-4">
          <p className="truncate text-sm">{admin?.displayName ?? admin?.email}</p>
          <p className="text-xs text-paper/50">{admin?.role}</p>
          <button
            onClick={() => logout.mutate()}
            className="mt-3 flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-paper/75 hover:bg-paper/10 hover:text-paper"
          >
            <LogOut size={15} /> Выйти
          </button>
        </div>
      </aside>

      <main className="flex-1 overflow-x-hidden">
        <div className="mx-auto max-w-6xl px-5 py-8 md:px-10">
          <Outlet />
        </div>
      </main>
    </div>
  )
}
