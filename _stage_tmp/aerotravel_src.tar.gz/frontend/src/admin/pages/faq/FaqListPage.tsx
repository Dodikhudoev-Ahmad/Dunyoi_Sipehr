import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { NavLink, useNavigate } from 'react-router-dom'
import { Plus } from 'lucide-react'
import { faqApi } from '@/api/faq'
import type { FaqItem } from '@/types/domain'
import { PageHeader } from '@/admin/components/PageHeader'
import { DataTable, type Column } from '@/admin/components/DataTable'
import { ConfirmDeleteButton } from '@/admin/components/ConfirmDeleteButton'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Skeleton } from '@/components/ui/Skeleton'
import { ErrorState } from '@/components/ui/ErrorState'
import { EmptyState } from '@/components/ui/EmptyState'
import { useToast } from '@/components/ui/Toast'

export function FaqListPage() {
  const { showToast } = useToast()
  const queryClient = useQueryClient()
  const navigate = useNavigate()
  const faq = useQuery({ queryKey: ['admin', 'faq'], queryFn: () => faqApi.adminList({ page: 1, pageSize: 100, sort: 'sortOrder' }) })

  const remove = useMutation({
    mutationFn: (id: string) => faqApi.adminDelete(id),
    onSuccess: () => {
      showToast('Вопрос удалён')
      void queryClient.invalidateQueries({ queryKey: ['admin', 'faq'] })
    },
    onError: () => showToast('Не удалось удалить вопрос', 'error'),
  })

  const columns: Column<FaqItem>[] = [
    { key: 'question', header: 'Вопрос', render: (f) => f.question },
    { key: 'category', header: 'Категория', render: (f) => f.category },
    { key: 'isPublished', header: 'Статус', render: (f) => <Badge tone={f.isPublished ? 'success' : 'neutral'}>{f.isPublished ? 'Опубликовано' : 'Черновик'}</Badge> },
    {
      key: 'actions',
      header: '',
      render: (f) => (
        <div className="flex items-center gap-2">
          <Button size="sm" variant="ghost" onClick={() => navigate(`/admin/faq/${f.id}`)}>
            Редактировать
          </Button>
          <ConfirmDeleteButton onConfirm={() => remove.mutate(f.id)} disabled={remove.isPending} />
        </div>
      ),
    },
  ]

  return (
    <div>
      <PageHeader
        title="Вопросы и ответы"
        action={
          <NavLink to="/admin/faq/new">
            <Button size="sm">
              <Plus size={15} /> Добавить вопрос
            </Button>
          </NavLink>
        }
      />
      {faq.isPending && <Skeleton className="h-40 w-full" />}
      {faq.isError && <ErrorState onRetry={() => faq.refetch()} />}
      {faq.isSuccess && faq.data.items.length === 0 && <EmptyState title="Вопросов пока нет" />}
      {faq.isSuccess && faq.data.items.length > 0 && <DataTable columns={columns} rows={faq.data.items} rowKey={(f) => f.id} />}
    </div>
  )
}
