import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { NavLink, useNavigate } from 'react-router-dom'
import { Plus, Star } from 'lucide-react'
import { testimonialsApi } from '@/api/testimonials'
import type { Testimonial } from '@/types/domain'
import { PageHeader } from '@/admin/components/PageHeader'
import { DataTable, type Column } from '@/admin/components/DataTable'
import { ConfirmDeleteButton } from '@/admin/components/ConfirmDeleteButton'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Skeleton } from '@/components/ui/Skeleton'
import { ErrorState } from '@/components/ui/ErrorState'
import { EmptyState } from '@/components/ui/EmptyState'
import { useToast } from '@/components/ui/Toast'

export function TestimonialsListPage() {
  const { showToast } = useToast()
  const queryClient = useQueryClient()
  const navigate = useNavigate()
  const testimonials = useQuery({
    queryKey: ['admin', 'testimonials'],
    queryFn: () => testimonialsApi.adminList({ page: 1, pageSize: 100, sort: 'sortOrder' }),
  })

  const remove = useMutation({
    mutationFn: (id: string) => testimonialsApi.adminDelete(id),
    onSuccess: () => {
      showToast('Отзыв удалён')
      void queryClient.invalidateQueries({ queryKey: ['admin', 'testimonials'] })
    },
    onError: () => showToast('Не удалось удалить отзыв', 'error'),
  })

  const columns: Column<Testimonial>[] = [
    { key: 'authorName', header: 'Автор', render: (t) => t.authorName },
    { key: 'authorCountry', header: 'Страна', render: (t) => t.authorCountry },
    { key: 'rating', header: 'Рейтинг', render: (t) => <span className="flex items-center gap-1"><Star size={13} className="text-brand" fill="currentColor" /> {t.rating}</span> },
    { key: 'isPublished', header: 'Статус', render: (t) => <Badge tone={t.isPublished ? 'success' : 'neutral'}>{t.isPublished ? 'Опубликовано' : 'Черновик'}</Badge> },
    {
      key: 'actions',
      header: '',
      render: (t) => (
        <div className="flex items-center gap-2">
          <Button size="sm" variant="ghost" onClick={() => navigate(`/admin/testimonials/${t.id}`)}>
            Редактировать
          </Button>
          <ConfirmDeleteButton onConfirm={() => remove.mutate(t.id)} disabled={remove.isPending} />
        </div>
      ),
    },
  ]

  return (
    <div>
      <PageHeader
        title="Отзывы"
        action={
          <NavLink to="/admin/testimonials/new">
            <Button size="sm">
              <Plus size={15} /> Добавить отзыв
            </Button>
          </NavLink>
        }
      />
      {testimonials.isPending && <Skeleton className="h-40 w-full" />}
      {testimonials.isError && <ErrorState onRetry={() => testimonials.refetch()} />}
      {testimonials.isSuccess && testimonials.data.items.length === 0 && <EmptyState title="Отзывов пока нет" />}
      {testimonials.isSuccess && testimonials.data.items.length > 0 && (
        <DataTable columns={columns} rows={testimonials.data.items} rowKey={(t) => t.id} />
      )}
    </div>
  )
}
