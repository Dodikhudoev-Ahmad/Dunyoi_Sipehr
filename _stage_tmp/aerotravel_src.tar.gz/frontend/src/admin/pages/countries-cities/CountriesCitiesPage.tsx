import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { Plus } from 'lucide-react'
import { countriesApi } from '@/api/countries'
import { citiesApi } from '@/api/cities'
import { LOCALES, type Country, type City } from '@/types/domain'
import { PageHeader } from '@/admin/components/PageHeader'
import { DataTable, type Column } from '@/admin/components/DataTable'
import { ConfirmDeleteButton } from '@/admin/components/ConfirmDeleteButton'
import { Button } from '@/components/ui/Button'
import { Input, FieldLabel } from '@/components/ui/Input'
import { Card } from '@/components/ui/Card'
import { Skeleton } from '@/components/ui/Skeleton'
import { ErrorState } from '@/components/ui/ErrorState'
import { EmptyState } from '@/components/ui/EmptyState'
import { useToast } from '@/components/ui/Toast'

interface CountryFormState {
  id: string | null
  isoCode: string
  sortOrder: number
  names: Record<string, string>
}

const emptyCountryForm: CountryFormState = { id: null, isoCode: '', sortOrder: 0, names: { ru: '', tg: '', en: '' } }

interface CityFormState {
  id: string | null
  countryId: string
  sortOrder: number
  names: Record<string, string>
}

export function CountriesCitiesPage() {
  const { showToast } = useToast()
  const queryClient = useQueryClient()

  const countries = useQuery({ queryKey: ['admin', 'countries'], queryFn: () => countriesApi.adminList({ page: 1, pageSize: 100, sort: 'sortOrder' }) })
  const cities = useQuery({ queryKey: ['admin', 'cities'], queryFn: () => citiesApi.adminList({ page: 1, pageSize: 200, sort: 'sortOrder' }) })

  const [countryForm, setCountryForm] = useState<CountryFormState | null>(null)
  const [cityForm, setCityForm] = useState<CityFormState | null>(null)

  const saveCountry = useMutation({
    mutationFn: (form: CountryFormState) => {
      const payload = {
        isoCode: form.isoCode,
        sortOrder: form.sortOrder,
        translations: LOCALES.map((locale) => ({ locale, name: form.names[locale] ?? '' })),
      }
      return form.id ? countriesApi.adminUpdate(form.id, payload) : countriesApi.adminCreate(payload)
    },
    onSuccess: () => {
      showToast('Страна сохранена')
      setCountryForm(null)
      void queryClient.invalidateQueries({ queryKey: ['admin', 'countries'] })
    },
    onError: () => showToast('Не удалось сохранить страну', 'error'),
  })

  const deleteCountry = useMutation({
    mutationFn: (id: string) => countriesApi.adminDelete(id),
    onSuccess: () => {
      showToast('Страна удалена')
      void queryClient.invalidateQueries({ queryKey: ['admin', 'countries'] })
    },
    onError: () => showToast('Не удалось удалить страну', 'error'),
  })

  const saveCity = useMutation({
    mutationFn: (form: CityFormState) => {
      const payload = {
        countryId: form.countryId,
        sortOrder: form.sortOrder,
        translations: LOCALES.map((locale) => ({ locale, name: form.names[locale] ?? '' })),
      }
      return form.id ? citiesApi.adminUpdate(form.id, payload) : citiesApi.adminCreate(payload)
    },
    onSuccess: () => {
      showToast('Город сохранён')
      setCityForm(null)
      void queryClient.invalidateQueries({ queryKey: ['admin', 'cities'] })
    },
    onError: () => showToast('Не удалось сохранить город', 'error'),
  })

  const deleteCity = useMutation({
    mutationFn: (id: string) => citiesApi.adminDelete(id),
    onSuccess: () => {
      showToast('Город удалён')
      void queryClient.invalidateQueries({ queryKey: ['admin', 'cities'] })
    },
    onError: () => showToast('Не удалось удалить город', 'error'),
  })

  const countryColumns: Column<Country>[] = [
    { key: 'name', header: 'Название', render: (c) => c.name },
    { key: 'isoCode', header: 'ISO', render: (c) => c.isoCode },
    { key: 'sortOrder', header: 'Порядок', render: (c) => c.sortOrder },
    {
      key: 'actions',
      header: '',
      render: (c) => (
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            variant="ghost"
            onClick={() =>
              setCountryForm({
                id: c.id,
                isoCode: c.isoCode,
                sortOrder: c.sortOrder,
                names: Object.fromEntries(LOCALES.map((l) => [l, c.translations?.find((t) => t.locale === l)?.name ?? (l === 'ru' ? c.name : '')])),
              })
            }
          >
            Редактировать
          </Button>
          <ConfirmDeleteButton onConfirm={() => deleteCountry.mutate(c.id)} disabled={deleteCountry.isPending} />
        </div>
      ),
    },
  ]

  const cityColumns: Column<City>[] = [
    { key: 'name', header: 'Название', render: (c) => c.name },
    { key: 'countryId', header: 'Страна', render: (c) => countries.data?.items.find((co) => co.id === c.countryId)?.name ?? '—' },
    { key: 'sortOrder', header: 'Порядок', render: (c) => c.sortOrder },
    {
      key: 'actions',
      header: '',
      render: (c) => (
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            variant="ghost"
            onClick={() =>
              setCityForm({
                id: c.id,
                countryId: c.countryId,
                sortOrder: c.sortOrder,
                names: Object.fromEntries(LOCALES.map((l) => [l, c.translations?.find((t) => t.locale === l)?.name ?? (l === 'ru' ? c.name : '')])),
              })
            }
          >
            Редактировать
          </Button>
          <ConfirmDeleteButton onConfirm={() => deleteCity.mutate(c.id)} disabled={deleteCity.isPending} />
        </div>
      ),
    },
  ]

  return (
    <div className="space-y-12">
      <div>
        <PageHeader
          title="Страны"
          action={
            <Button size="sm" onClick={() => setCountryForm(emptyCountryForm)}>
              <Plus size={15} /> Добавить страну
            </Button>
          }
        />
        {countryForm && (
          <Card className="mb-6 space-y-4 p-5">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div>
                <FieldLabel>ISO-код</FieldLabel>
                <Input value={countryForm.isoCode} maxLength={2} onChange={(e) => setCountryForm({ ...countryForm, isoCode: e.target.value.toUpperCase() })} />
              </div>
              <div>
                <FieldLabel>Порядок сортировки</FieldLabel>
                <Input type="number" value={countryForm.sortOrder} onChange={(e) => setCountryForm({ ...countryForm, sortOrder: Number(e.target.value) })} />
              </div>
            </div>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
              {LOCALES.map((locale) => (
                <div key={locale}>
                  <FieldLabel>Название ({locale})</FieldLabel>
                  <Input
                    value={countryForm.names[locale] ?? ''}
                    onChange={(e) => setCountryForm({ ...countryForm, names: { ...countryForm.names, [locale]: e.target.value } })}
                  />
                </div>
              ))}
            </div>
            <div className="flex gap-2">
              <Button size="sm" onClick={() => saveCountry.mutate(countryForm)} disabled={saveCountry.isPending}>
                Сохранить
              </Button>
              <Button size="sm" variant="ghost" onClick={() => setCountryForm(null)}>
                Отмена
              </Button>
            </div>
          </Card>
        )}
        {countries.isPending && <Skeleton className="h-40 w-full" />}
        {countries.isError && <ErrorState onRetry={() => countries.refetch()} />}
        {countries.isSuccess && countries.data.items.length === 0 && <EmptyState title="Стран пока нет" />}
        {countries.isSuccess && countries.data.items.length > 0 && (
          <DataTable columns={countryColumns} rows={countries.data.items} rowKey={(c) => c.id} />
        )}
      </div>

      <div>
        <PageHeader
          title="Города"
          action={
            <Button
              size="sm"
              onClick={() => setCityForm({ id: null, countryId: countries.data?.items[0]?.id ?? '', sortOrder: 0, names: { ru: '', tg: '', en: '' } })}
              disabled={!countries.data?.items.length}
            >
              <Plus size={15} /> Добавить город
            </Button>
          }
        />
        {cityForm && (
          <Card className="mb-6 space-y-4 p-5">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div>
                <FieldLabel>Страна</FieldLabel>
                <select
                  className="w-full rounded-lg border border-ink/15 bg-white px-4 py-2.5"
                  value={cityForm.countryId}
                  onChange={(e) => setCityForm({ ...cityForm, countryId: e.target.value })}
                >
                  {countries.data?.items.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <FieldLabel>Порядок сортировки</FieldLabel>
                <Input type="number" value={cityForm.sortOrder} onChange={(e) => setCityForm({ ...cityForm, sortOrder: Number(e.target.value) })} />
              </div>
            </div>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
              {LOCALES.map((locale) => (
                <div key={locale}>
                  <FieldLabel>Название ({locale})</FieldLabel>
                  <Input
                    value={cityForm.names[locale] ?? ''}
                    onChange={(e) => setCityForm({ ...cityForm, names: { ...cityForm.names, [locale]: e.target.value } })}
                  />
                </div>
              ))}
            </div>
            <div className="flex gap-2">
              <Button size="sm" onClick={() => saveCity.mutate(cityForm)} disabled={saveCity.isPending}>
                Сохранить
              </Button>
              <Button size="sm" variant="ghost" onClick={() => setCityForm(null)}>
                Отмена
              </Button>
            </div>
          </Card>
        )}
        {cities.isPending && <Skeleton className="h-40 w-full" />}
        {cities.isError && <ErrorState onRetry={() => cities.refetch()} />}
        {cities.isSuccess && cities.data.items.length === 0 && <EmptyState title="Городов пока нет" />}
        {cities.isSuccess && cities.data.items.length > 0 && <DataTable columns={cityColumns} rows={cities.data.items} rowKey={(c) => c.id} />}
      </div>
    </div>
  )
}
