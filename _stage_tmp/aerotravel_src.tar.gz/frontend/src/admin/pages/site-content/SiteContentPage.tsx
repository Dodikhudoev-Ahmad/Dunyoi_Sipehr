import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { siteContentApi } from '@/api/siteContent'
import { LOCALES, type Locale, type SiteContent } from '@/types/domain'
import { PageHeader } from '@/admin/components/PageHeader'
import { LocaleTabs } from '@/admin/components/LocaleTabs'
import { Card } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { Input, Textarea, FieldLabel } from '@/components/ui/Input'
import { Skeleton } from '@/components/ui/Skeleton'
import { ErrorState } from '@/components/ui/ErrorState'
import { EmptyState } from '@/components/ui/EmptyState'
import { useToast } from '@/components/ui/Toast'

interface FormState {
  id: string | null
  key: string
  titles: Record<Locale, string>
  bodies: Record<Locale, string>
}

function toFormState(entry: SiteContent | null, key: string): FormState {
  if (!entry) return { id: null, key, titles: { ru: '', tg: '', en: '' }, bodies: { ru: '', tg: '', en: '' } }
  return {
    id: entry.id,
    key: entry.key,
    titles: Object.fromEntries(LOCALES.map((l) => [l, entry.translations?.find((t) => t.locale === l)?.title ?? (l === 'ru' ? entry.title : '')])) as Record<Locale, string>,
    bodies: Object.fromEntries(LOCALES.map((l) => [l, entry.translations?.find((t) => t.locale === l)?.body ?? (l === 'ru' ? entry.body : '')])) as Record<Locale, string>,
  }
}

export function SiteContentPage() {
  const { showToast } = useToast()
  const queryClient = useQueryClient()
  const [activeLocale, setActiveLocale] = useState<Locale>('ru')
  const [selectedKey, setSelectedKey] = useState<string | null>(null)

  const list = useQuery({ queryKey: ['admin', 'site-content'], queryFn: () => siteContentApi.adminList({ page: 1, pageSize: 100, sort: 'key' }) })

  const activeEntry = list.data?.items.find((e) => e.key === selectedKey) ?? null
  const [form, setForm] = useState<FormState | null>(null)

  function openKey(key: string) {
    setSelectedKey(key)
    setForm(toFormState(list.data?.items.find((e) => e.key === key) ?? null, key))
    setActiveLocale('ru')
  }

  const save = useMutation({
    mutationFn: () => {
      if (!form) throw new Error('No form state')
      const payload = {
        key: form.key,
        translations: LOCALES.map((locale) => ({ locale, title: form.titles[locale], body: form.bodies[locale] })),
      }
      return form.id ? siteContentApi.adminUpdate(form.id, payload) : siteContentApi.adminCreate(payload)
    },
    onSuccess: () => {
      showToast('Контент сохранён')
      void queryClient.invalidateQueries({ queryKey: ['admin', 'site-content'] })
    },
    onError: () => showToast('Не удалось сохранить контент', 'error'),
  })

  const KNOWN_KEYS = ['hero', 'about', 'contacts', 'privacy-policy']

  return (
    <div>
      <PageHeader title="Контент сайта" />

      {list.isPending && <Skeleton className="h-40 w-full" />}
      {list.isError && <ErrorState onRetry={() => list.refetch()} />}

      {list.isSuccess && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-[240px_1fr]">
          <div className="space-y-1">
            {[...new Set([...KNOWN_KEYS, ...list.data.items.map((e) => e.key)])].map((key) => (
              <button
                key={key}
                onClick={() => openKey(key)}
                className={`block w-full rounded-lg px-3 py-2 text-left text-sm ${selectedKey === key ? 'bg-ink text-paper' : 'text-slate hover:bg-ink/5'}`}
              >
                {key}
              </button>
            ))}
          </div>

          <div>
            {!form && <EmptyState title="Выберите ключ слева, чтобы редактировать содержимое" />}
            {form && (
              <Card className="space-y-5 p-6">
                <div>
                  <FieldLabel>Ключ</FieldLabel>
                  <Input value={form.key} disabled={Boolean(activeEntry)} onChange={(e) => setForm({ ...form, key: e.target.value })} />
                </div>

                <LocaleTabs active={activeLocale} onChange={setActiveLocale} />
                <div>
                  <FieldLabel>Заголовок</FieldLabel>
                  <Input
                    value={form.titles[activeLocale]}
                    onChange={(e) => setForm({ ...form, titles: { ...form.titles, [activeLocale]: e.target.value } })}
                  />
                </div>
                <div>
                  <FieldLabel>Текст</FieldLabel>
                  <Textarea
                    className="min-h-48"
                    value={form.bodies[activeLocale]}
                    onChange={(e) => setForm({ ...form, bodies: { ...form.bodies, [activeLocale]: e.target.value } })}
                  />
                </div>

                <Button onClick={() => save.mutate()} disabled={save.isPending}>
                  Сохранить
                </Button>
              </Card>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
