import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { NavLink, useNavigate } from 'react-router-dom'
import { Plus } from 'lucide-react'
import { offersApi } from '@/api/offers'
import type { Offer } from '@/types/domain'
import { PageHeader } from '@/admin/components/PageHeader'
import { DataTable, type Column } from '@/admin/components/DataTable'
import { ConfirmDeleteButton } from '@/admin/components/ConfirmDeleteButton'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Skeleton } from '@/components/ui/Skeleton'
import { ErrorState } from '@/components/ui/ErrorState'
import { EmptyState } from '@/components/ui/EmptyState'
import { useToast } from '@/components/ui/Toast'
import { useListState } from '@/admin/hooks/useListState'
import { Pagination } from '@/admin/components/Pagination'

export function OffersListPage() {
  const { showToast } = useToast()
  const queryClient = useQueryClient()
  const navigate = useNavigate()
  const { page, setPage, sort, dir, toggleSort } = useListState('sortOrder')

  const offers = useQuery({
    queryKey: ['admin', 'offers', page, sort, dir],
    queryFn: () => offersApi.adminList({ page, pageSize: 10, sort, dir }),
  })

  const remove = useMutation({
    mutationFn: (id: string) => offersApi.adminDelete(id),
    onSuccess: () => {
      showToast('Предложение удалено')
      void queryClient.invalidateQueries({ queryKey: ['admin', 'offers'] })
    },
    onError: () => showToast('Не удалось удалить предложение', 'error'),
  })

  const columns: Column<Offer>[] = [
    { key: 'title', header: 'Название', render: (o) => o.title },
    { key: 'priceFrom', header: 'Цена от', sortable: true, render: (o) => `${o.priceFrom} ${o.currency.toUpperCase()}` },
    { key: 'isFeatured', header: 'Избранное', render: (o) => (o.isFeatured ? <Badge tone="accent">Да</Badge> : '—') },
    { key: 'isPublished', header: 'Статус', sortable: true, render: (o) => <Badge tone={o.isPublished ? 'success' : 'neutral'}>{o.isPublished ? 'Опубликовано' : 'Черновик'}</Badge> },
    {
      key: 'actions',
      header: '',
      render: (o) => (
        <div className="flex items-center gap-2">
          <Button size="sm" variant="ghost" onClick={() => navigate(`/admin/offers/${o.id}`)}>
            Редактировать
          </Button>
          <ConfirmDeleteButton onConfirm={() => remove.mutate(o.id)} disabled={remove.isPending} />
        </div>
      ),
    },
  ]

  return (
    <div>
      <PageHeader
        title="Предложения"
        action={
          <NavLink to="/admin/offers/new">
            <Button size="sm">
              <Plus size={15} /> Добавить предложение
            </Button>
          </NavLink>
        }
      />
      {offers.isPending && <Skeleton className="h-40 w-full" />}
      {offers.isError && <ErrorState onRetry={() => offers.refetch()} />}
      {offers.isSuccess && offers.data.items.length === 0 && <EmptyState title="Предложений пока нет" />}
      {offers.isSuccess && offers.data.items.length > 0 && (
        <>
          <DataTable columns={columns} rows={offers.data.items} rowKey={(o) => o.id} sort={sort} dir={dir} onSort={toggleSort} />
          <Pagination page={offers.data.page} totalPages={offers.data.totalPages} onChange={setPage} />
        </>
      )}
    </div>
  )
}
