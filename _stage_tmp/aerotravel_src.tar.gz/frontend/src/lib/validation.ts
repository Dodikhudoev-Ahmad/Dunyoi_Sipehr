import { z } from 'zod'

/**
 * Travel Request form schema (React Hook Form + Zod per CLAUDE.md / MASTER_TZ).
 * `website` is the honeypot field: real users never see or fill it, so any
 * non-empty value gets rejected client-side too (defense in depth; the
 * authoritative check happens server-side per API_CONTRACT.md).
 */
export const travelRequestSchema = z.object({
  fullName: z.string().trim().min(2, { message: 'validation.minLength' }),
  email: z.string().trim().email({ message: 'validation.invalidEmail' }),
  phone: z
    .string()
    .trim()
    .min(6, { message: 'validation.invalidPhone' })
    .regex(/^[+\d][\d\s()-]{5,}$/, { message: 'validation.invalidPhone' }),
  destinationId: z.string().optional(),
  offerId: z.string().optional(),
  passengersAdults: z.number().int().min(1, { message: 'validation.min0' }),
  passengersChildren: z.number().int().min(0, { message: 'validation.min0' }),
  message: z.string().trim().max(2000).optional(),
  consentAccepted: z.literal(true, { message: 'validation.consentRequired' }),
  website: z.string().max(0).optional(),
})

export type TravelRequestFormValues = z.infer<typeof travelRequestSchema>
