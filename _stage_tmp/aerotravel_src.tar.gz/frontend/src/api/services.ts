import { apiDelete, apiGet, apiPost, apiPut } from '@/api/client'
import { toQueryString } from '@/api/queryString'
import type { PagedResult, ListQuery } from '@/types/api'
import type { Service, Locale } from '@/types/domain'

export const servicesApi = {
  publicList: (locale: Locale) => apiGet<Service[]>(`/public/services${toQueryString({ locale })}`),

  adminList: (query: ListQuery) => apiGet<PagedResult<Service>>(`/admin/services${toQueryString({ ...query })}`),
  adminGet: (id: string) => apiGet<Service>(`/admin/services/${id}`),
  adminCreate: (payload: Partial<Service> & { translations: Service['translations'] }) =>
    apiPost<Service>('/admin/services', payload),
  adminUpdate: (id: string, payload: Partial<Service> & { translations: Service['translations'] }) =>
    apiPut<Service>(`/admin/services/${id}`, payload),
  adminDelete: (id: string) => apiDelete<void>(`/admin/services/${id}`),
}
