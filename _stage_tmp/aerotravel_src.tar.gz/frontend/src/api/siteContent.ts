import { apiDelete, apiGet, apiPost, apiPut } from '@/api/client'
import { toQueryString } from '@/api/queryString'
import type { PagedResult, ListQuery } from '@/types/api'
import type { SiteContent, Locale } from '@/types/domain'

export const siteContentApi = {
  publicGet: (key: string, locale: Locale) =>
    apiGet<SiteContent>(`/public/site-content/${key}${toQueryString({ locale })}`),

  adminList: (query: ListQuery) =>
    apiGet<PagedResult<SiteContent>>(`/admin/site-content${toQueryString({ ...query })}`),
  adminGet: (id: string) => apiGet<SiteContent>(`/admin/site-content/${id}`),
  adminCreate: (payload: Partial<SiteContent> & { translations: SiteContent['translations'] }) =>
    apiPost<SiteContent>('/admin/site-content', payload),
  adminUpdate: (id: string, payload: Partial<SiteContent> & { translations: SiteContent['translations'] }) =>
    apiPut<SiteContent>(`/admin/site-content/${id}`, payload),
  adminDelete: (id: string) => apiDelete<void>(`/admin/site-content/${id}`),
}
