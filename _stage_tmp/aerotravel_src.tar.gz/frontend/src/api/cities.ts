import { apiDelete, apiGet, apiPost, apiPut } from '@/api/client'
import { toQueryString } from '@/api/queryString'
import type { PagedResult, ListQuery } from '@/types/api'
import type { City, Locale } from '@/types/domain'

export const citiesApi = {
  publicList: (locale: Locale, countryId?: string) =>
    apiGet<City[]>(`/public/cities${toQueryString({ locale, countryId })}`),

  adminList: (query: ListQuery & { countryId?: string }) =>
    apiGet<PagedResult<City>>(`/admin/cities${toQueryString({ ...query })}`),
  adminGet: (id: string) => apiGet<City>(`/admin/cities/${id}`),
  adminCreate: (payload: Partial<City> & { translations: City['translations'] }) =>
    apiPost<City>('/admin/cities', payload),
  adminUpdate: (id: string, payload: Partial<City> & { translations: City['translations'] }) =>
    apiPut<City>(`/admin/cities/${id}`, payload),
  adminDelete: (id: string) => apiDelete<void>(`/admin/cities/${id}`),
}
