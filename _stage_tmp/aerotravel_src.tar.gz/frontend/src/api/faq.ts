import { apiDelete, apiGet, apiPost, apiPut } from '@/api/client'
import { toQueryString } from '@/api/queryString'
import type { PagedResult, ListQuery } from '@/types/api'
import type { FaqItem, Locale } from '@/types/domain'

export const faqApi = {
  publicList: (locale: Locale) => apiGet<FaqItem[]>(`/public/faq${toQueryString({ locale })}`),

  adminList: (query: ListQuery) => apiGet<PagedResult<FaqItem>>(`/admin/faq${toQueryString({ ...query })}`),
  adminGet: (id: string) => apiGet<FaqItem>(`/admin/faq/${id}`),
  adminCreate: (payload: Partial<FaqItem> & { translations: FaqItem['translations'] }) =>
    apiPost<FaqItem>('/admin/faq', payload),
  adminUpdate: (id: string, payload: Partial<FaqItem> & { translations: FaqItem['translations'] }) =>
    apiPut<FaqItem>(`/admin/faq/${id}`, payload),
  adminDelete: (id: string) => apiDelete<void>(`/admin/faq/${id}`),
}
