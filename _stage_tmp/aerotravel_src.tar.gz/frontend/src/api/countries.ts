import { apiDelete, apiGet, apiPost, apiPut } from '@/api/client'
import { toQueryString } from '@/api/queryString'
import type { PagedResult, ListQuery } from '@/types/api'
import type { Country, Locale } from '@/types/domain'

export const countriesApi = {
  publicList: (locale: Locale) => apiGet<Country[]>(`/public/countries${toQueryString({ locale })}`),

  adminList: (query: ListQuery) =>
    apiGet<PagedResult<Country>>(`/admin/countries${toQueryString({ ...query })}`),
  adminGet: (id: string) => apiGet<Country>(`/admin/countries/${id}`),
  adminCreate: (payload: Partial<Country> & { translations: Country['translations'] }) =>
    apiPost<Country>('/admin/countries', payload),
  adminUpdate: (id: string, payload: Partial<Country> & { translations: Country['translations'] }) =>
    apiPut<Country>(`/admin/countries/${id}`, payload),
  adminDelete: (id: string) => apiDelete<void>(`/admin/countries/${id}`),
}
