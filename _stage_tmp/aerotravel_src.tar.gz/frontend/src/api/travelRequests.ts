import { apiGet, apiPatch, apiPost } from '@/api/client'
import { toQueryString } from '@/api/queryString'
import type { PagedResult, ListQuery } from '@/types/api'
import type { TravelRequest, TravelRequestStatus, Locale } from '@/types/domain'

export interface TravelRequestSubmission {
  fullName: string
  email: string
  phone: string
  preferredLocale: Locale
  destinationId?: string | null
  offerId?: string | null
  passengersAdults: number
  passengersChildren: number
  message?: string
  consentAccepted: boolean
  /** Honeypot — must stay empty; bots that fill hidden fields get silently rejected server-side. */
  website?: string
  sourceUtm?: { utmSource?: string; utmMedium?: string; utmCampaign?: string }
}

export const travelRequestsApi = {
  publicSubmit: (payload: TravelRequestSubmission) =>
    apiPost<TravelRequest>('/public/travel-requests', payload),

  adminList: (query: ListQuery & { status?: TravelRequestStatus; from?: string; to?: string }) =>
    apiGet<PagedResult<TravelRequest>>(`/admin/travel-requests${toQueryString({ ...query })}`),
  adminGet: (id: string) => apiGet<TravelRequest>(`/admin/travel-requests/${id}`),
  adminSetStatus: (id: string, status: TravelRequestStatus) =>
    apiPatch<TravelRequest>(`/admin/travel-requests/${id}/status`, { status }),
  adminAssign: (id: string, adminUserId: string | null) =>
    apiPatch<TravelRequest>(`/admin/travel-requests/${id}/assign`, { adminUserId }),
}
