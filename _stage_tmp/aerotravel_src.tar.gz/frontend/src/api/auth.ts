import { apiGet, apiPost } from '@/api/client'
import type { AdminUser } from '@/types/domain'

export interface LoginResponse {
  accessToken: string
  expiresAtUtc: string
  admin: AdminUser
}

export const authApi = {
  login: (email: string, password: string) => apiPost<LoginResponse>('/auth/login', { email, password }),
  refresh: () => apiPost<{ accessToken: string; expiresAtUtc: string }>('/auth/refresh'),
  logout: () => apiPost<void>('/auth/logout'),
  me: () => apiGet<AdminUser>('/auth/me'),
  bootstrap: (payload: { email: string; password: string; displayName: string }) =>
    apiPost<LoginResponse>('/auth/bootstrap', payload),
}
