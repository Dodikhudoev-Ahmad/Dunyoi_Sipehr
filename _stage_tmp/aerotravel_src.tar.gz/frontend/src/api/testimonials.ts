import { apiDelete, apiGet, apiPost, apiPut } from '@/api/client'
import { toQueryString } from '@/api/queryString'
import type { PagedResult, ListQuery } from '@/types/api'
import type { Testimonial, Locale } from '@/types/domain'

export const testimonialsApi = {
  publicList: (locale: Locale) => apiGet<Testimonial[]>(`/public/testimonials${toQueryString({ locale })}`),

  adminList: (query: ListQuery) =>
    apiGet<PagedResult<Testimonial>>(`/admin/testimonials${toQueryString({ ...query })}`),
  adminGet: (id: string) => apiGet<Testimonial>(`/admin/testimonials/${id}`),
  adminCreate: (payload: Partial<Testimonial> & { translations: Testimonial['translations'] }) =>
    apiPost<Testimonial>('/admin/testimonials', payload),
  adminUpdate: (id: string, payload: Partial<Testimonial> & { translations: Testimonial['translations'] }) =>
    apiPut<Testimonial>(`/admin/testimonials/${id}`, payload),
  adminDelete: (id: string) => apiDelete<void>(`/admin/testimonials/${id}`),
}
