import { useLocation, useNavigate } from 'react-router-dom'
import { Globe } from 'lucide-react'
import { LOCALES, type Locale } from '@/types/domain'
import { useLocale, localizedPath } from '@/i18n/LocaleContext'
import { cn } from '@/lib/cn'

const LABELS: Record<Locale, string> = { ru: 'RU', tg: 'TG', en: 'EN' }

/** Strips the current locale prefix from the pathname, leaving the bare route path. */
function stripLocalePrefix(pathname: string, locale: Locale): string {
  if (locale === 'ru') return pathname
  const prefix = `/${locale}`
  if (pathname === prefix) return '/'
  if (pathname.startsWith(`${prefix}/`)) return pathname.slice(prefix.length)
  return pathname
}

export function LocaleSwitcher({ dark = false }: { dark?: boolean }) {
  const locale = useLocale()
  const location = useLocation()
  const navigate = useNavigate()
  const bare = stripLocalePrefix(location.pathname, locale)

  return (
    <div className={cn('flex items-center gap-1 rounded-full border px-2 py-1', dark ? 'border-brand-accent/30' : 'border-brand/20')}>
      <Globe size={14} className={dark ? 'text-paper/70' : 'text-slate'} aria-hidden />
      {LOCALES.map((l) => (
        <button
          key={l}
          onClick={() => navigate(localizedPath(l, bare))}
          className={cn(
            'rounded-full px-2 py-0.5 text-xs font-medium tracking-wide transition-colors',
            l === locale
              ? dark
                ? 'bg-brand-accent text-paper'
                : 'bg-brand text-paper'
              : dark
                ? 'text-paper/70 hover:bg-brand-accent/15 hover:text-paper'
                : 'text-slate hover:bg-brand-subtle hover:text-brand',
          )}
          aria-current={l === locale ? 'true' : undefined}
        >
          {LABELS[l]}
        </button>
      ))}
    </div>
  )
}
