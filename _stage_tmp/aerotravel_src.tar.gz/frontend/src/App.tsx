import { BrowserRouter, Routes } from 'react-router-dom'
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClient } from '@/lib/queryClient'
import { ToastProvider } from '@/components/ui/Toast'
import { publicRoutesFor } from '@/routes/publicRoutes'
import { adminRoutes } from '@/routes/adminRoutes'

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ToastProvider>
        <BrowserRouter>
          <Routes>
            {publicRoutesFor('ru', '/')}
            {publicRoutesFor('en', '/en')}
            {publicRoutesFor('tg', '/tg')}
            {adminRoutes()}
          </Routes>
        </BrowserRouter>
      </ToastProvider>
    </QueryClientProvider>
  )
}
