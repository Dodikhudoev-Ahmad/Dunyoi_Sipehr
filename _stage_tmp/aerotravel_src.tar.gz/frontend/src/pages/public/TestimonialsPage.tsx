import { useTranslation } from 'react-i18next'
import { useLocale } from '@/i18n/LocaleContext'
import { useTestimonials } from '@/hooks/usePublicData'
import { Section } from '@/components/ui/Section'
import { SkeletonCardGrid } from '@/components/ui/Skeleton'
import { EmptyState } from '@/components/ui/EmptyState'
import { ErrorState } from '@/components/ui/ErrorState'
import { TestimonialCard } from '@/components/sections/TestimonialCard'

export function TestimonialsPage() {
  const { t } = useTranslation()
  const locale = useLocale()
  const testimonials = useTestimonials(locale)

  return (
    <Section withMap className="pt-16">
      <h1 className="mb-10 text-3xl font-medium md:text-5xl">{t('testimonialsPage.title')}</h1>

      {testimonials.isPending && <SkeletonCardGrid count={6} />}
      {testimonials.isError && <ErrorState onRetry={() => testimonials.refetch()} />}
      {testimonials.isSuccess && testimonials.data.length === 0 && <EmptyState title={t('testimonialsPage.empty')} />}
      {testimonials.isSuccess && testimonials.data.length > 0 && (
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {testimonials.data.map((testimonial, i) => (
            <TestimonialCard key={testimonial.id} testimonial={testimonial} index={i} />
          ))}
        </div>
      )}
    </Section>
  )
}
