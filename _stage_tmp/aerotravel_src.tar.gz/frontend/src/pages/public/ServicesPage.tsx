import { useTranslation } from 'react-i18next'
import { useLocale } from '@/i18n/LocaleContext'
import { useServices } from '@/hooks/usePublicData'
import { Section } from '@/components/ui/Section'
import { Skeleton } from '@/components/ui/Skeleton'
import { EmptyState } from '@/components/ui/EmptyState'
import { ErrorState } from '@/components/ui/ErrorState'
import { ServicesEditorial } from '@/components/sections/ServicesEditorial'

export function ServicesPage() {
  const { t } = useTranslation()
  const locale = useLocale()
  const services = useServices(locale)

  return (
    <Section withMap className="pt-16">
      <div className="mb-14 max-w-2xl">
        <h1 className="font-display text-3xl font-medium md:text-5xl">{t('services.title')}</h1>
        <p className="mt-3 text-muted">{t('services.subtitle')}</p>
      </div>

      {services.isPending && (
        <div className="space-y-6 border-t border-text/10 pt-8">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-20 w-full" />
          ))}
        </div>
      )}
      {services.isError && <ErrorState onRetry={() => services.refetch()} />}
      {services.isSuccess && services.data.length === 0 && <EmptyState title={t('services.empty')} />}
      {services.isSuccess && services.data.length > 0 && <ServicesEditorial services={services.data} />}
    </Section>
  )
}
