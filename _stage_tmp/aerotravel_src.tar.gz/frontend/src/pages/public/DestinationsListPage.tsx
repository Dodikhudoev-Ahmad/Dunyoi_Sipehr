import { useTranslation } from 'react-i18next'
import { useLocale } from '@/i18n/LocaleContext'
import { useDestinations } from '@/hooks/usePublicData'
import { Section } from '@/components/ui/Section'
import { SkeletonCardGrid } from '@/components/ui/Skeleton'
import { EmptyState } from '@/components/ui/EmptyState'
import { ErrorState } from '@/components/ui/ErrorState'
import { DestinationCard } from '@/components/sections/DestinationCard'

export function DestinationsListPage() {
  const { t } = useTranslation()
  const locale = useLocale()
  const destinations = useDestinations(locale, { pageSize: 24 })

  return (
    <Section withMap className="pt-16">
      <div className="mb-10 max-w-2xl">
        <h1 className="text-3xl font-medium md:text-5xl">{t('destinations.title')}</h1>
        <p className="mt-3 text-slate">{t('destinations.subtitle')}</p>
      </div>

      {destinations.isPending && <SkeletonCardGrid count={6} />}
      {destinations.isError && <ErrorState onRetry={() => destinations.refetch()} />}
      {destinations.isSuccess && destinations.data.items.length === 0 && <EmptyState title={t('destinations.empty')} />}
      {destinations.isSuccess && destinations.data.items.length > 0 && (
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {destinations.data.items.map((d, i) => (
            <DestinationCard key={d.id} destination={d} index={i} />
          ))}
        </div>
      )}
    </Section>
  )
}
