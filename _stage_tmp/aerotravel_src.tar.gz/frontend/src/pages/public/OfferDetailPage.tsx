import { useParams, NavLink } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import { ArrowLeft, CalendarDays, Clock } from 'lucide-react'
import { useLocale, localizedPath } from '@/i18n/LocaleContext'
import { useOffer } from '@/hooks/usePublicData'
import { Section } from '@/components/ui/Section'
import { ErrorState } from '@/components/ui/ErrorState'
import { Skeleton } from '@/components/ui/Skeleton'
import { Button } from '@/components/ui/Button'
import { NotFoundPage } from '@/pages/public/NotFoundPage'
import { currencySymbol } from '@/lib/currency'

export function OfferDetailPage() {
  const { slug = '' } = useParams()
  const { t } = useTranslation()
  const locale = useLocale()
  const offer = useOffer(slug, locale)

  if (offer.isPending) {
    return (
      <Section className="pt-16">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="mt-4 aspect-16/7 w-full" />
      </Section>
    )
  }

  if (offer.isError) {
    if (offer.error.status === 404) return <NotFoundPage />
    return (
      <Section className="pt-16">
        <ErrorState onRetry={() => offer.refetch()} />
      </Section>
    )
  }

  const o = offer.data
  const currency = currencySymbol(t, o.currency)
  const gallery = o.galleryUrls ?? []
  const cover = gallery[0]

  return (
    <>
      <Section className="pb-8 pt-16">
        <NavLink to={localizedPath(locale, '/offers')} className="mb-6 inline-flex items-center gap-1 text-sm text-slate hover:text-ink">
          <ArrowLeft size={14} /> {t('offers.backToList')}
        </NavLink>
        <h1 className="text-3xl font-medium md:text-5xl">{o.title}</h1>
        <p className="mt-4 max-w-2xl text-lg text-slate">{o.summary}</p>
        <div className="mt-6 flex flex-wrap items-center gap-6">
          <span className="text-2xl font-semibold text-brand">
            {t('offers.priceFrom')} {currency}{o.priceFrom.toLocaleString(locale)}
          </span>
          {o.durationDays && (
            <span className="flex items-center gap-1 text-sm text-slate">
              <CalendarDays size={15} /> {t('offers.duration', { count: o.durationDays })}
            </span>
          )}
          {o.validUntilUtc && (
            <span className="flex items-center gap-1 text-sm text-slate">
              <Clock size={15} /> {t('offers.validUntil')} {new Date(o.validUntilUtc).toLocaleDateString(locale)}
            </span>
          )}
        </div>
      </Section>

      <Section className="pt-0" tone="paper">
        {cover && (
          <div className="overflow-hidden rounded-2xl">
            <img src={cover} alt={o.title} className="aspect-16/7 w-full object-cover" />
          </div>
        )}

        <p className="mt-10 max-w-3xl whitespace-pre-line leading-relaxed text-slate">{o.description}</p>

        {gallery.length > 1 && (
          <div className="mt-10 grid grid-cols-2 gap-4 md:grid-cols-4">
            {gallery.slice(1).map((url, i) => (
              <img key={i} src={url} alt="" loading="lazy" className="aspect-square w-full rounded-xl object-cover" />
            ))}
          </div>
        )}

        <div className="mt-14 text-center">
          <NavLink to={localizedPath(locale, `/travel-request?offerId=${o.id}`)}>
            <Button size="lg">{t('offers.requestThis')}</Button>
          </NavLink>
        </div>
      </Section>
    </>
  )
}
