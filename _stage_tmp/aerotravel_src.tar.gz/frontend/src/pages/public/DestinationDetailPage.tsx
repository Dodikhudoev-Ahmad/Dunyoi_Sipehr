import { useParams, NavLink } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import { CheckCircle2, ArrowLeft } from 'lucide-react'
import { useLocale, localizedPath } from '@/i18n/LocaleContext'
import { useDestination, useOffers } from '@/hooks/usePublicData'
import { Section } from '@/components/ui/Section'
import { ErrorState } from '@/components/ui/ErrorState'
import { Skeleton } from '@/components/ui/Skeleton'
import { EmptyState } from '@/components/ui/EmptyState'
import { Button } from '@/components/ui/Button'
import { OfferCard } from '@/components/sections/OfferCard'
import { NotFoundPage } from '@/pages/public/NotFoundPage'

export function DestinationDetailPage() {
  const { slug = '' } = useParams()
  const { t } = useTranslation()
  const locale = useLocale()
  const destination = useDestination(slug, locale)
  const offers = useOffers(locale, { destinationId: destination.data?.id, pageSize: 6 })

  if (destination.isPending) {
    return (
      <Section className="pt-16">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="mt-4 aspect-16/7 w-full" />
      </Section>
    )
  }

  if (destination.isError) {
    if (destination.error.status === 404) return <NotFoundPage />
    return (
      <Section className="pt-16">
        <ErrorState onRetry={() => destination.refetch()} />
      </Section>
    )
  }

  const d = destination.data

  return (
    <>
      <Section className="pb-8 pt-16">
        <NavLink to={localizedPath(locale, '/destinations')} className="mb-6 inline-flex items-center gap-1 text-sm text-slate hover:text-ink">
          <ArrowLeft size={14} /> {t('destinations.backToList')}
        </NavLink>
        <h1 className="text-3xl font-medium md:text-5xl">{d.title}</h1>
        <p className="mt-4 max-w-2xl text-lg text-slate">{d.summary}</p>
      </Section>

      <Section className="pt-0" tone="paper">
        <div className="overflow-hidden rounded-2xl">
          <img src={d.heroImageUrl} alt={d.title} className="aspect-16/7 w-full object-cover" />
        </div>

        <div className="mt-10 grid grid-cols-1 gap-10 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <p className="whitespace-pre-line leading-relaxed text-slate">{d.description}</p>
          </div>
          {d.highlights.length > 0 && (
            <div>
              <h2 className="mb-3 text-lg font-medium">{t('destinations.highlights')}</h2>
              <ul className="space-y-2">
                {d.highlights.map((h, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-slate">
                    <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-brand" /> {h}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>

        {d.galleryUrls.length > 0 && (
          <div className="mt-10 grid grid-cols-2 gap-4 md:grid-cols-4">
            {d.galleryUrls.map((url, i) => (
              <img key={i} src={url} alt="" loading="lazy" className="aspect-square w-full rounded-xl object-cover" />
            ))}
          </div>
        )}

        <div className="mt-14">
          <div className="mb-6 flex items-center justify-between">
            <h2 className="text-2xl font-medium">{t('destinations.viewOffers')}</h2>
          </div>
          {offers.isPending && <Skeleton className="h-40 w-full" />}
          {offers.isSuccess && offers.data.items.length === 0 && <EmptyState title={t('offers.empty')} />}
          {offers.isSuccess && offers.data.items.length > 0 && (
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {offers.data.items.map((o, i) => (
                <OfferCard key={o.id} offer={o} index={i} />
              ))}
            </div>
          )}
        </div>

        <div className="mt-14 text-center">
          <NavLink to={localizedPath(locale, `/travel-request?destinationId=${d.id}`)}>
            <Button size="lg">{t('offers.requestThis')}</Button>
          </NavLink>
        </div>
      </Section>
    </>
  )
}
