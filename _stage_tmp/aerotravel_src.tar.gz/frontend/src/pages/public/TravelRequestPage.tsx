import { useSearchParams } from 'react-router-dom'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { useTranslation } from 'react-i18next'
import { useMutation } from '@tanstack/react-query'
import { CheckCircle2 } from 'lucide-react'
import { useLocale } from '@/i18n/LocaleContext'
import { useDestinations, useOffers } from '@/hooks/usePublicData'
import { travelRequestsApi } from '@/api/travelRequests'
import { ApiError } from '@/types/api'
import { travelRequestSchema, type TravelRequestFormValues } from '@/lib/validation'
import { Section } from '@/components/ui/Section'
import { Card } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { FieldLabel, FieldError, Input, Textarea, Select } from '@/components/ui/Input'

export function TravelRequestPage() {
  const { t } = useTranslation()
  const locale = useLocale()
  const [searchParams] = useSearchParams()

  const destinations = useDestinations(locale, { pageSize: 100 })
  const offers = useOffers(locale, { pageSize: 100 })

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitSuccessful },
    reset,
  } = useForm<TravelRequestFormValues>({
    resolver: zodResolver(travelRequestSchema),
    defaultValues: {
      fullName: '',
      email: '',
      phone: '',
      destinationId: searchParams.get('destinationId') ?? '',
      offerId: searchParams.get('offerId') ?? '',
      passengersAdults: 1,
      passengersChildren: 0,
      message: '',
      consentAccepted: undefined as unknown as true,
      website: '',
    },
  })

  const mutation = useMutation({
    mutationFn: (values: TravelRequestFormValues) =>
      travelRequestsApi.publicSubmit({
        fullName: values.fullName,
        email: values.email,
        phone: values.phone,
        preferredLocale: locale,
        destinationId: values.destinationId || null,
        offerId: values.offerId || null,
        passengersAdults: values.passengersAdults,
        passengersChildren: values.passengersChildren,
        message: values.message,
        consentAccepted: values.consentAccepted,
        website: values.website,
      }),
    onSuccess: () => reset(),
  })

  const onSubmit = handleSubmit((values) => mutation.mutate(values))

  return (
    <Section withMap className="pt-16">
      <div className="mx-auto max-w-2xl">
        <h1 className="text-3xl font-medium md:text-5xl">{t('travelRequest.title')}</h1>
        <p className="mt-3 text-slate">{t('travelRequest.subtitle')}</p>

        <Card className="mt-10 p-6 md:p-8">
          {isSubmitSuccessful && mutation.isSuccess ? (
            <div className="flex flex-col items-center gap-3 py-8 text-center">
              <CheckCircle2 size={36} className="text-success" />
              <h2 className="text-xl font-medium">{t('travelRequest.successTitle')}</h2>
              <p className="text-slate">{t('travelRequest.successBody')}</p>
            </div>
          ) : (
            <form onSubmit={onSubmit} noValidate className="space-y-5">
              {/* Honeypot: hidden from real users via .honeypot-field (see index.css), left in the tab order for bots. */}
              <div className="honeypot-field" aria-hidden="true">
                <label htmlFor="website">Website</label>
                <input id="website" type="text" tabIndex={-1} autoComplete="off" {...register('website')} />
              </div>

              <div>
                <FieldLabel htmlFor="fullName">{t('travelRequest.fullName')}</FieldLabel>
                <Input id="fullName" invalid={Boolean(errors.fullName)} {...register('fullName')} />
                <FieldError>{errors.fullName && t(errors.fullName.message ?? 'validation.required', { count: 2 })}</FieldError>
              </div>

              <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                <div>
                  <FieldLabel htmlFor="email">{t('travelRequest.email')}</FieldLabel>
                  <Input id="email" type="email" invalid={Boolean(errors.email)} {...register('email')} />
                  <FieldError>{errors.email && t(errors.email.message ?? 'validation.invalidEmail')}</FieldError>
                </div>
                <div>
                  <FieldLabel htmlFor="phone">{t('travelRequest.phone')}</FieldLabel>
                  <Input id="phone" type="tel" invalid={Boolean(errors.phone)} {...register('phone')} />
                  <FieldError>{errors.phone && t(errors.phone.message ?? 'validation.invalidPhone')}</FieldError>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                <div>
                  <FieldLabel htmlFor="destinationId">{t('travelRequest.destination')}</FieldLabel>
                  <Select id="destinationId" {...register('destinationId')}>
                    <option value="">{t('travelRequest.none')}</option>
                    {destinations.data?.items.map((d) => (
                      <option key={d.id} value={d.id}>
                        {d.title}
                      </option>
                    ))}
                  </Select>
                </div>
                <div>
                  <FieldLabel htmlFor="offerId">{t('travelRequest.offer')}</FieldLabel>
                  <Select id="offerId" {...register('offerId')}>
                    <option value="">{t('travelRequest.none')}</option>
                    {offers.data?.items.map((o) => (
                      <option key={o.id} value={o.id}>
                        {o.title}
                      </option>
                    ))}
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                <div>
                  <FieldLabel htmlFor="passengersAdults">{t('travelRequest.adults')}</FieldLabel>
                  <Input
                    id="passengersAdults"
                    type="number"
                    min={1}
                    invalid={Boolean(errors.passengersAdults)}
                    {...register('passengersAdults', { valueAsNumber: true })}
                  />
                  <FieldError>{errors.passengersAdults && t('validation.min0')}</FieldError>
                </div>
                <div>
                  <FieldLabel htmlFor="passengersChildren">{t('travelRequest.children')}</FieldLabel>
                  <Input
                    id="passengersChildren"
                    type="number"
                    min={0}
                    invalid={Boolean(errors.passengersChildren)}
                    {...register('passengersChildren', { valueAsNumber: true })}
                  />
                  <FieldError>{errors.passengersChildren && t('validation.min0')}</FieldError>
                </div>
              </div>

              <div>
                <FieldLabel htmlFor="message">{t('travelRequest.message')}</FieldLabel>
                <Textarea id="message" placeholder={t('travelRequest.messagePlaceholder')} {...register('message')} />
              </div>

              <label className="flex items-start gap-2 text-sm text-slate">
                <input type="checkbox" className="mt-0.5" {...register('consentAccepted')} />
                {t('travelRequest.consent')}
              </label>
              <FieldError>{errors.consentAccepted && t('validation.consentRequired')}</FieldError>

              {mutation.isError && (
                <p className="text-sm text-danger">
                  {t('travelRequest.errorTitle')}
                  {mutation.error instanceof ApiError && mutation.error.message ? `: ${mutation.error.message}` : ''}
                </p>
              )}

              <Button type="submit" size="lg" className="w-full" disabled={mutation.isPending}>
                {mutation.isPending ? t('travelRequest.submitting') : t('travelRequest.submit')}
              </Button>
            </form>
          )}
        </Card>
      </div>
    </Section>
  )
}
