import { useTranslation } from 'react-i18next'
import { useLocale } from '@/i18n/LocaleContext'
import { useOffers } from '@/hooks/usePublicData'
import { Section } from '@/components/ui/Section'
import { SkeletonCardGrid } from '@/components/ui/Skeleton'
import { EmptyState } from '@/components/ui/EmptyState'
import { ErrorState } from '@/components/ui/ErrorState'
import { OfferCard } from '@/components/sections/OfferCard'

export function OffersListPage() {
  const { t } = useTranslation()
  const locale = useLocale()
  const offers = useOffers(locale, { pageSize: 24 })

  return (
    <Section withMap className="pt-16">
      <div className="mb-10 max-w-2xl">
        <h1 className="text-3xl font-medium md:text-5xl">{t('offers.title')}</h1>
        <p className="mt-3 text-slate">{t('offers.subtitle')}</p>
      </div>

      {offers.isPending && <SkeletonCardGrid count={6} />}
      {offers.isError && <ErrorState onRetry={() => offers.refetch()} />}
      {offers.isSuccess && offers.data.items.length === 0 && <EmptyState title={t('offers.empty')} />}
      {offers.isSuccess && offers.data.items.length > 0 && (
        <div className="grid grid-cols-1 gap-x-8 gap-y-14 sm:grid-cols-2 lg:grid-cols-3">
          {offers.data.items.map((o, i) => (
            <OfferCard key={o.id} offer={o} index={i} />
          ))}
        </div>
      )}
    </Section>
  )
}
