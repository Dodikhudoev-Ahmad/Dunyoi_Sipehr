/**
 * Domain model types mirroring docs/DOMAIN_MODEL.md.
 * The API returns entities already resolved to the requested locale for public
 * endpoints (translation fields flattened), and with an explicit `translations`
 * array for admin endpoints (so every locale can be edited at once).
 */

export type Locale = 'ru' | 'tg' | 'en'

export const LOCALES: Locale[] = ['ru', 'tg', 'en']
export const DEFAULT_LOCALE: Locale = 'ru'

export type Currency = 'USD' | 'EUR' | 'TJS'

export type AdminRole = 'SuperAdmin' | 'Editor'

export type TravelRequestStatus = 'New' | 'Contacted' | 'Qualified' | 'Won' | 'Lost'

export interface CountryTranslation {
  locale: Locale
  name: string
}

export interface Country {
  id: string
  isoCode: string
  sortOrder: number
  name: string
  translations?: CountryTranslation[]
}

export interface CityTranslation {
  locale: Locale
  name: string
}

export interface City {
  id: string
  countryId: string
  sortOrder: number
  name: string
  translations?: CityTranslation[]
}

export interface DestinationTranslation {
  locale: Locale
  title: string
  summary: string
  description: string
  highlights: string[]
  metaTitle?: string
  metaDescription?: string
}

export interface Destination {
  id: string
  cityId: string
  slug: string
  heroImageUrl: string
  galleryUrls: string[]
  isFeatured: boolean
  isPublished: boolean
  sortOrder: number
  createdAtUtc: string
  updatedAtUtc: string
  title: string
  summary: string
  description: string
  highlights: string[]
  translations?: DestinationTranslation[]
}

export interface ServiceTranslation {
  locale: Locale
  name: string
  description: string
}

export interface Service {
  id: string
  icon: string
  isPublished: boolean
  sortOrder: number
  name: string
  description: string
  translations?: ServiceTranslation[]
}

export interface OfferTranslation {
  locale: Locale
  title: string
  summary: string
  description: string
  metaTitle?: string
  metaDescription?: string
}

export interface Offer {
  id: string
  destinationId: string | null
  slug: string
  priceFrom: number
  currency: Currency
  durationDays: number | null
  /** Present on public list responses only (OfferListItemDto); absent on detail/admin responses. */
  heroImageUrl?: string | null
  /** Present on public detail responses only (OfferDetailDto); absent on public list responses. */
  galleryUrls?: string[]
  validUntilUtc: string | null
  isFeatured: boolean
  isPublished: boolean
  sortOrder: number
  serviceIds: string[]
  title: string
  summary: string
  description: string
  destination?: Pick<Destination, 'id' | 'slug' | 'title'> | null
  translations?: OfferTranslation[]
}

export interface TestimonialTranslation {
  locale: Locale
  quote: string
}

export interface Testimonial {
  id: string
  authorName: string
  authorCountry: string
  avatarUrl: string | null
  rating: number
  isPublished: boolean
  sortOrder: number
  quote: string
  translations?: TestimonialTranslation[]
}

export interface FaqItemTranslation {
  locale: Locale
  question: string
  answer: string
}

export interface FaqItem {
  id: string
  category: string
  sortOrder: number
  isPublished: boolean
  question: string
  answer: string
  translations?: FaqItemTranslation[]
}

export interface SiteContentTranslation {
  locale: Locale
  title: string
  body: string
  extraJson?: string | null
}

export interface SiteContent {
  id: string
  key: string
  title: string
  body: string
  extraJson?: string | null
  translations?: SiteContentTranslation[]
}

export interface SourceUtm {
  utmSource?: string
  utmMedium?: string
  utmCampaign?: string
}

export interface TravelRequest {
  id: string
  createdAtUtc: string
  status: TravelRequestStatus
  fullName: string
  email: string
  phone: string
  preferredLocale: Locale
  destinationId: string | null
  destinationSnapshotTitle: string | null
  offerId: string | null
  offerSnapshotTitle: string | null
  passengersAdults: number
  passengersChildren: number
  message: string | null
  consentAcceptedAtUtc: string
  sourceUtm: SourceUtm | null
  sourceIp: string | null
  sourceLocale: Locale
  assignedAdminUserId: string | null
}

export interface AdminUser {
  id: string
  email: string
  displayName: string
  role: AdminRole
  isActive: boolean
  createdAtUtc: string
}

export interface AuditLog {
  id: string
  entityType: string
  entityId: string
  action: string
  adminUserId: string | null
  timestamp: string
  detailsJson: string | null
}
