# Architecture Decisions

## DEC-001
**Problem:** How to store multilingual content (ru/tg/en) for CMS entities.
**Decision:** Dedicated `*Translation` child tables (EntityId FK, Locale, translated columns), unique index on (EntityId, Locale).
**Reason:** Queryable, indexable, admin-editable per-locale without JSON parsing; EF Core relational mapping is simpler than JSON column diffing.
**Impact:** Every translatable aggregate gets a companion translation entity + EF configuration.

## DEC-002
**Problem:** MASTER_TZ.md did not exist prior to this build.
**Decision:** Authored it from the build-mode specification supplied in the initiating instructions, treating it as authoritative going forward.
**Reason:** Explicit user instruction: absence of spec is not a blocker, invent and continue.
**Impact:** Product scope (travel agency lead-gen site) is a design choice made by the build agent, not the user; amend via new DEC entries if requirements diverge.

## DEC-003
**Problem:** CQRS implementation choice (hand-rolled vs MediatR).
**Decision:** MediatR for command/query dispatch, with FluentValidation pipeline behavior.
**Reason:** Standard, low-boilerplate, well-understood pattern; keeps controllers thin without a bespoke dispatcher.
**Impact:** Adds MediatR + FluentValidation.DependencyInjectionExtensions package dependency.

## DEC-004
**Problem:** Anti-spam for public Travel Request submission without external CAPTCHA credentials.
**Decision:** Honeypot hidden field (reject if filled) + ASP.NET Core built-in rate limiting (fixed window per IP) on the endpoint.
**Reason:** No third-party CAPTCHA key available (external blocker, logged in BLOCKERS.md); this gives meaningful protection without external dependency.
**Impact:** `docs/BLOCKERS.md` entry for optional future reCAPTCHA/hCaptcha upgrade.

## DEC-005
**Problem:** Result pattern vs exceptions for expected application failures.
**Decision:** `Result<T>` / `Result` return type for Application layer handlers; exceptions reserved for truly unexpected failures, caught by global exception middleware.
**Reason:** Explicit control flow for validation/not-found/conflict cases; avoids exception-driven business logic.
**Impact:** Controllers map `Result` failures to ProblemDetails via a shared extension.

## DEC-007
**Problem:** Localized routing scheme — prefix every locale or treat default as unprefixed.
**Decision:** `ru` (default) served unprefixed at root; `tg`/`en` use `/tg` and `/en` prefixes.
**Reason:** Cleanest canonical URLs for the primary market (ru) while still giving tg/en explicit, crawlable, hreflang-able paths.
**Impact:** Frontend router and backend SEO (hreflang/sitemap) must special-case the unprefixed default.

## DEC-006
**Problem:** Hosting stack for production without live credentials.
**Decision:** Backend + PostgreSQL → Railway (Dockerfile-based); Frontend static build → Netlify.
**Reason:** Specified in build instructions as target platforms.
**Impact:** `railway.json`/Dockerfile and `netlify.toml` prepared in Stage 22 even without accounts.
