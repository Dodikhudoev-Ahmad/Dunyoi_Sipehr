# Progress Log

## Stage 0 — Specification Completion — DONE (2026-08-09)
Authored MASTER_TZ.md, DECISIONS.md, DOMAIN_MODEL.md, SITEMAP.md, API_CONTRACT.md, DESIGN_BIBLE.md from scratch (no prior spec existed — see DEC-002). BLOCKERS.md seeded with known external dependencies.

## Stage 1 — Repository Foundation — DONE (2026-08-09)
Fixed initial csproj wiring gaps (missing `Microsoft.EntityFrameworkCore` ref in Application, missing `FrameworkReference` for `IHttpContextAccessor` in Infrastructure, EF Core/Npgsql version conflict). Backend builds with 0 warnings/0 errors.

## Stage 2 — Backend Feature Completion — DONE (2026-08-09)
`Program.cs` fully wired: Serilog + correlation-ID middleware, JWT Bearer auth, RFC7807 global exception handling with `errorCode`, CORS, fixed-window rate limiting (login + public travel-request submission per DEC-004), `/health` (Npgsql check), Swagger (dev-only, Bearer scheme), `api/v1` route prefix.

Full CQRS CRUD added for Countries, Cities, Destinations, Services, Offers, Testimonials, FAQ, SiteContent (public queries + admin commands), Travel Requests (public create w/ honeypot, admin status-transition/assign enforcing the state machine), and Audit Log (write-on-mutation + `GET /admin/audit-log`). Api Controllers added for all public/auth/admin routes per `API_CONTRACT.md`.

`InitialCreate` EF Core migration generated (via `IDesignTimeDbContextFactory`, `dotnet-ef` as a local tool). Dev-only seeder (`DevSeeder`, gated to `Development`, applies migrations then seeds minimal ru/tg/en placeholder data — picsum.photos images per BLK-007). Test suite expanded from 1 placeholder to 42 tests (Result/Error, Login, Destination CRUD, TravelRequest state machine, validators) using `EntityFrameworkCore.InMemory` (Tests project only) and hand-written fakes.

Bug found & fixed during this stage: `LoginCommandHandler`/`RefreshTokenCommandHandler` relied on EF graph-fixup instead of explicitly adding the new `RefreshToken`, causing a save failure — fixed with explicit `db.RefreshTokens.Add(...)`.

Verified: `dotnet build` → 0 Warning(s), 0 Error(s). `dotnet test` → 42/42 passing.

Known gap: no per-endpoint role-based authorization beyond `[Authorize]` (API_CONTRACT.md doesn't specify role restrictions); migration not yet applied against a live Postgres instance (none available locally — generates cleanly via design-time factory, see BLK-001).

## Stage 3 — Frontend Foundation — DONE (2026-08-09)
Scaffolded `frontend/` from scratch: React 18 + TS (strict) + Vite, Tailwind v4 (`@tailwindcss/vite`), React Router, TanStack Query, React Hook Form + Zod, Axios, `motion`, lucide-react — the fixed stack from `MASTER_TZ.md` §6.

Typed API layer (`src/api/`) mirroring `API_CONTRACT.md` exactly, with Bearer-token interceptor, single-flight 401→refresh→retry flow (httpOnly cookie), and RFC7807→typed `ApiError` parsing. i18n via react-i18next, `ru` (default/unprefixed) / `tg` / `en` routing with fallback to `ru`, per `SITEMAP.md`.

Public site (home w/ Aero Map Background motif, destinations, offers, services, about, testimonials, FAQ, contacts, travel-request form w/ CSS-hidden honeypot, 404) and admin CMS (login, protected routes, full CRUD for every CMS entity, travel-request board, audit log viewer) built out. Small design-system primitives in `src/components/ui/` per `DESIGN_BIBLE.md`. `.env.example` + `netlify.toml` per BLK-003.

Verified: `npm run build` → 0 TypeScript errors (one advisory bundle-size warning, no code-splitting attempted). `npm run lint` (oxlint) → exit 0, 4 advisory fast-refresh warnings only.

Known gap: bundle not code-split (~1.3MB single JS chunk); no bootstrap-admin UI page (endpoint exists in the API layer, not in SITEMAP.md so no page was built); no frontend automated tests yet.

## Stage 4 — Integration Smoke Test — DONE (2026-08-09)
Applied `InitialCreate` against a real local Postgres (via `db.Database.MigrateAsync()` on startup), ran the API and dev seeder live: `/health` → Healthy, `GET /public/destinations` and `/public/countries` return real seeded ru data, `POST /auth/bootstrap` creates the first SuperAdmin, `POST /auth/login` issues a working Bearer token, `GET /admin/destinations` (authenticated) returns data, and an intentionally-incomplete `POST /public/travel-requests` correctly returns a localized RFC7807 `VALIDATION_FAILED` response. Ran the Vite dev server against the live API — SPA routes (`/`, `/destinations`, `/en`, `/admin/login`) all serve 200.

Not yet done: no browser-level visual check (no browser automation tool available in this environment) — HTTP-level checks only. Remaining known gaps unchanged: JS bundle not code-split, no per-endpoint role-based authorization, no frontend automated tests.
