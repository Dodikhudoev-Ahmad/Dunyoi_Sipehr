using AeroTravel.Api.Common;
using AeroTravel.Application.Common.Interfaces;
using AeroTravel.Application.Features.Countries.Commands;
using AeroTravel.Application.Features.Countries.Dtos;
using AeroTravel.Application.Features.Countries.Queries;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace AeroTravel.Api.Controllers.Admin;

[Route("api/v1/admin/countries")]
[Authorize]
public class AdminCountriesController(ISender mediator, ICurrentUserService currentUser) : AdminApiControllerBase(mediator, currentUser)
{
    [HttpGet]
    public async Task<IActionResult> List([FromQuery] int page = 1, [FromQuery] int pageSize = 20, CancellationToken ct = default)
        => (await Mediator.Send(new ListAdminCountriesQuery(page, pageSize), ct)).ToActionResult().Result!;

    [HttpGet("{id:guid}")]
    public async Task<IActionResult> GetById(Guid id, CancellationToken ct)
        => (await Mediator.Send(new GetAdminCountryByIdQuery(id), ct)).ToActionResult().Result!;

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] UpsertCountryInput input, CancellationToken ct)
    {
        var result = await Mediator.Send(new CreateCountryCommand(input, CurrentAdminUserId), ct);
        return result.IsSuccess
            ? CreatedAtAction(nameof(GetById), new { id = result.Value }, new { id = result.Value })
            : result.ToActionResult().Result!;
    }

    [HttpPut("{id:guid}")]
    public async Task<IActionResult> Update(Guid id, [FromBody] UpsertCountryInput input, CancellationToken ct)
        => (await Mediator.Send(new UpdateCountryCommand(id, input, CurrentAdminUserId), ct)).ToActionResult();

    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Delete(Guid id, CancellationToken ct)
        => (await Mediator.Send(new DeleteCountryCommand(id, CurrentAdminUserId), ct)).ToActionResult();
}
