using AeroTravel.Api.Common;
using AeroTravel.Application.Features.TravelRequests.Commands;
using AeroTravel.Application.Features.TravelRequests.Dtos;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;

namespace AeroTravel.Api.Controllers.Public;

[Route("api/v1/public/travel-requests")]
[EnableRateLimiting("travel-requests")]
public class PublicTravelRequestsController(ISender mediator) : ApiControllerBase(mediator)
{
    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateTravelRequestInput input, CancellationToken ct)
    {
        var sourceIp = HttpContext.Connection.RemoteIpAddress?.ToString();
        var result = await Mediator.Send(new CreateTravelRequestCommand(input, sourceIp), ct);
        return result.ToActionResult().Result ?? NoContent();
    }
}
