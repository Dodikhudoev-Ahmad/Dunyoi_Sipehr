using AeroTravel.Domain.Common;
using AeroTravel.Domain.Enums;

namespace AeroTravel.Domain.Entities;

public class TravelRequest : Entity
{
    public DateTime CreatedAtUtc { get; private set; } = DateTime.UtcNow;
    public TravelRequestStatus Status { get; private set; } = TravelRequestStatus.New;

    public string FullName { get; private set; } = default!;
    public string Email { get; private set; } = default!;
    public string Phone { get; private set; } = default!;
    public Locale PreferredLocale { get; private set; }

    public Guid? DestinationId { get; private set; }
    public string? DestinationSnapshotTitle { get; private set; }
    public Guid? OfferId { get; private set; }
    public string? OfferSnapshotTitle { get; private set; }

    public int PassengersAdults { get; private set; }
    public int PassengersChildren { get; private set; }
    public string? Message { get; private set; }

    public DateTime ConsentAcceptedAtUtc { get; private set; }
    public string? SourceUtm { get; private set; }
    public string? SourceIp { get; private set; }
    public Locale SourceLocale { get; private set; }

    public Guid? AssignedAdminUserId { get; private set; }

    private TravelRequest() { }

    public TravelRequest(
        string fullName, string email, string phone, Locale preferredLocale,
        int passengersAdults, int passengersChildren, string? message,
        Guid? destinationId, string? destinationSnapshotTitle,
        Guid? offerId, string? offerSnapshotTitle,
        string? sourceUtm, string? sourceIp, Locale sourceLocale)
    {
        FullName = fullName;
        Email = email;
        Phone = phone;
        PreferredLocale = preferredLocale;
        PassengersAdults = passengersAdults;
        PassengersChildren = passengersChildren;
        Message = message;
        DestinationId = destinationId;
        DestinationSnapshotTitle = destinationSnapshotTitle;
        OfferId = offerId;
        OfferSnapshotTitle = offerSnapshotTitle;
        SourceUtm = sourceUtm;
        SourceIp = sourceIp;
        SourceLocale = sourceLocale;
        ConsentAcceptedAtUtc = DateTime.UtcNow;
    }

    private static readonly Dictionary<TravelRequestStatus, TravelRequestStatus[]> AllowedTransitions = new()
    {
        [TravelRequestStatus.New] = [TravelRequestStatus.Contacted, TravelRequestStatus.Lost],
        [TravelRequestStatus.Contacted] = [TravelRequestStatus.Qualified, TravelRequestStatus.Lost],
        [TravelRequestStatus.Qualified] = [TravelRequestStatus.Won, TravelRequestStatus.Lost],
        [TravelRequestStatus.Won] = [],
        [TravelRequestStatus.Lost] = [],
    };

    public bool CanTransitionTo(TravelRequestStatus next) => AllowedTransitions[Status].Contains(next);

    public void TransitionTo(TravelRequestStatus next)
    {
        if (!CanTransitionTo(next))
            throw new InvalidOperationException($"Cannot transition TravelRequest from {Status} to {next}.");
        Status = next;
    }

    public void AssignTo(Guid? adminUserId) => AssignedAdminUserId = adminUserId;
}
