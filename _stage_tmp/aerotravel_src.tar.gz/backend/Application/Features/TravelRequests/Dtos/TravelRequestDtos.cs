using AeroTravel.Domain.Enums;

namespace AeroTravel.Application.Features.TravelRequests.Dtos;

public record CreateTravelRequestInput(
    string FullName, string Email, string Phone, Locale PreferredLocale,
    int PassengersAdults, int PassengersChildren, string? Message,
    Guid? DestinationId, Guid? OfferId, string? SourceUtm, Locale SourceLocale,
    bool ConsentAccepted, string? Website);

public record TravelRequestListItemDto(
    Guid Id, DateTime CreatedAtUtc, TravelRequestStatus Status, string FullName, string Email, string Phone,
    string? DestinationSnapshotTitle, string? OfferSnapshotTitle, Guid? AssignedAdminUserId);

public record TravelRequestDetailDto(
    Guid Id, DateTime CreatedAtUtc, TravelRequestStatus Status,
    string FullName, string Email, string Phone, Locale PreferredLocale,
    Guid? DestinationId, string? DestinationSnapshotTitle, Guid? OfferId, string? OfferSnapshotTitle,
    int PassengersAdults, int PassengersChildren, string? Message,
    DateTime ConsentAcceptedAtUtc, string? SourceUtm, string? SourceIp, Locale SourceLocale,
    Guid? AssignedAdminUserId);
