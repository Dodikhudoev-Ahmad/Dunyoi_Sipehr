using AeroTravel.Application.Common.Interfaces;
using AeroTravel.Application.Common.Models;
using AeroTravel.Application.Features.TravelRequests.Dtos;
using AeroTravel.Domain.Entities;
using FluentValidation;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace AeroTravel.Application.Features.TravelRequests.Commands;

// Public lead-capture endpoint. Anti-spam per DEC-004: a honeypot field ("website") that real
// users never see/fill; bots that autofill every field trip it. We reject rather than
// silently-drop so the frontend can show a generic error without a fake "success" response
// that would make client-side debugging confusing; the field is invisible to humans anyway.
public record CreateTravelRequestCommand(CreateTravelRequestInput Input, string? SourceIp) : IRequest<Result<Guid>>;

public class CreateTravelRequestCommandValidator : AbstractValidator<CreateTravelRequestCommand>
{
    public CreateTravelRequestCommandValidator()
    {
        RuleFor(x => x.Input.FullName).NotEmpty().MaximumLength(200);
        RuleFor(x => x.Input.Email).NotEmpty().EmailAddress();
        RuleFor(x => x.Input.Phone).NotEmpty().MaximumLength(50);
        RuleFor(x => x.Input.PassengersAdults).GreaterThanOrEqualTo(1);
        RuleFor(x => x.Input.PassengersChildren).GreaterThanOrEqualTo(0);
        RuleFor(x => x.Input.ConsentAccepted).Equal(true).WithMessage("Consent is required.");
    }
}

public class CreateTravelRequestCommandHandler(IApplicationDbContext db) : IRequestHandler<CreateTravelRequestCommand, Result<Guid>>
{
    public async Task<Result<Guid>> Handle(CreateTravelRequestCommand request, CancellationToken cancellationToken)
    {
        var input = request.Input;

        if (!string.IsNullOrWhiteSpace(input.Website))
            return Result.Failure<Guid>(Error.Validation("VALIDATION_FAILED", "Request could not be submitted."));

        string? destinationTitle = null;
        if (input.DestinationId is { } destinationId)
        {
            destinationTitle = await db.Destinations
                .Where(d => d.Id == destinationId)
                .Select(d => d.Translations.FirstOrDefault(t => t.Locale == input.PreferredLocale) ?? d.Translations.FirstOrDefault())
                .Select(t => t!.Title)
                .FirstOrDefaultAsync(cancellationToken);
        }

        string? offerTitle = null;
        if (input.OfferId is { } offerId)
        {
            offerTitle = await db.Offers
                .Where(o => o.Id == offerId)
                .Select(o => o.Translations.FirstOrDefault(t => t.Locale == input.PreferredLocale) ?? o.Translations.FirstOrDefault())
                .Select(t => t!.Title)
                .FirstOrDefaultAsync(cancellationToken);
        }

        var travelRequest = new TravelRequest(
            input.FullName, input.Email, input.Phone, input.PreferredLocale,
            input.PassengersAdults, input.PassengersChildren, input.Message,
            input.DestinationId, destinationTitle, input.OfferId, offerTitle,
            input.SourceUtm, request.SourceIp, input.SourceLocale);

        db.TravelRequests.Add(travelRequest);
        await db.SaveChangesAsync(cancellationToken);
        return Result.Success(travelRequest.Id);
    }
}
