using AeroTravel.Application.Common.Models;
using AeroTravel.Application.Features.TravelRequests.Commands;
using AeroTravel.Application.Features.TravelRequests.Dtos;
using AeroTravel.Domain.Enums;
using AeroTravel.Tests.Common;

namespace AeroTravel.Tests.Features.TravelRequests;

public class CreateTravelRequestCommandTests
{
    private static CreateTravelRequestInput ValidInput(string? website = null) => new(
        "Jane Doe", "jane@example.com", "+992000000", Locale.Ru,
        2, 0, null, null, null, null, Locale.Ru, ConsentAccepted: true, Website: website);

    [Fact]
    public async Task Handle_ValidRequest_CreatesEntity()
    {
        using var db = TestDb.Create();
        var handler = new CreateTravelRequestCommandHandler(db);

        var result = await handler.Handle(new CreateTravelRequestCommand(ValidInput(), "1.2.3.4"), CancellationToken.None);

        Assert.True(result.IsSuccess);
        Assert.Single(db.TravelRequests);
    }

    [Fact]
    public async Task Handle_HoneypotFilled_RejectsSilently_WithoutPersisting()
    {
        using var db = TestDb.Create();
        var handler = new CreateTravelRequestCommandHandler(db);

        var result = await handler.Handle(new CreateTravelRequestCommand(ValidInput(website: "http://spam.example"), "1.2.3.4"), CancellationToken.None);

        Assert.True(result.IsFailure);
        Assert.Equal(ErrorType.Validation, result.Error!.Type);
        Assert.Empty(db.TravelRequests);
    }

    [Theory]
    [InlineData("", "jane@example.com", "+992000000", true)]
    [InlineData("Jane", "not-an-email", "+992000000", true)]
    [InlineData("Jane", "jane@example.com", "", true)]
    [InlineData("Jane", "jane@example.com", "+992000000", false)]
    public void Validator_RejectsInvalidInput(string fullName, string email, string phone, bool consent)
    {
        var validator = new CreateTravelRequestCommandValidator();
        var input = new CreateTravelRequestInput(fullName, email, phone, Locale.Ru, 1, 0, null, null, null, null, Locale.Ru, consent, null);

        var result = validator.Validate(new CreateTravelRequestCommand(input, null));

        Assert.False(result.IsValid);
    }
}
