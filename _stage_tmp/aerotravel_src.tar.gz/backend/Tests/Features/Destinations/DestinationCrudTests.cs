using AeroTravel.Application.Common.Models;
using AeroTravel.Application.Features.Destinations.Commands;
using AeroTravel.Application.Features.Destinations.Dtos;
using AeroTravel.Domain.Entities;
using AeroTravel.Domain.Enums;
using AeroTravel.Tests.Common;

namespace AeroTravel.Tests.Features.Destinations;

public class DestinationCrudTests
{
    private static UpsertDestinationInput ValidInput(Guid cityId, string slug = "test-slug") => new(
        cityId, slug, null, [], true, false, 0,
        [new DestinationTranslationInput(Locale.Ru, "Title", "Summary", "Description", ["h1"], null, null)]);

    [Fact]
    public async Task Create_Succeeds_AndPersists()
    {
        using var db = TestDb.Create();
        var country = new Country("TJ");
        var city = new City(country.Id);
        db.Countries.Add(country);
        db.Cities.Add(city);
        await db.SaveChangesAsync(CancellationToken.None);

        var handler = new CreateDestinationCommandHandler(db);
        var result = await handler.Handle(new CreateDestinationCommand(ValidInput(city.Id), null), CancellationToken.None);

        Assert.True(result.IsSuccess);
        Assert.Single(db.Destinations);
        Assert.Single(db.AuditLogs);
    }

    [Fact]
    public async Task Create_DuplicateSlug_ReturnsConflict()
    {
        using var db = TestDb.Create();
        var country = new Country("TJ");
        var city = new City(country.Id);
        db.Countries.Add(country);
        db.Cities.Add(city);
        var existing = new Destination(city.Id, "test-slug");
        db.Destinations.Add(existing);
        await db.SaveChangesAsync(CancellationToken.None);

        var handler = new CreateDestinationCommandHandler(db);
        var result = await handler.Handle(new CreateDestinationCommand(ValidInput(city.Id), null), CancellationToken.None);

        Assert.True(result.IsFailure);
        Assert.Equal(ErrorType.Conflict, result.Error!.Type);
        Assert.Equal("CONFLICT_DUPLICATE", result.Error.Code);
    }

    [Fact]
    public async Task Update_NonExistent_ReturnsNotFound()
    {
        using var db = TestDb.Create();
        var handler = new UpdateDestinationCommandHandler(db);

        var result = await handler.Handle(new UpdateDestinationCommand(Guid.NewGuid(), ValidInput(Guid.NewGuid()), null), CancellationToken.None);

        Assert.True(result.IsFailure);
        Assert.Equal(ErrorType.NotFound, result.Error!.Type);
    }

    [Fact]
    public async Task Delete_Existing_RemovesEntity_AndWritesAudit()
    {
        using var db = TestDb.Create();
        var country = new Country("TJ");
        var city = new City(country.Id);
        var destination = new Destination(city.Id, "to-delete");
        db.Countries.Add(country);
        db.Cities.Add(city);
        db.Destinations.Add(destination);
        await db.SaveChangesAsync(CancellationToken.None);

        var handler = new DeleteDestinationCommandHandler(db);
        var adminId = Guid.NewGuid();
        var result = await handler.Handle(new DeleteDestinationCommand(destination.Id, adminId), CancellationToken.None);

        Assert.True(result.IsSuccess);
        Assert.Empty(db.Destinations);
        Assert.Contains(db.AuditLogs, a => a.Action == "Delete" && a.AdminUserId == adminId);
    }
}
