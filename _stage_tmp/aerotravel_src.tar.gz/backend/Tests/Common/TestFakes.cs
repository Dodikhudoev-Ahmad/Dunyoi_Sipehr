using AeroTravel.Application.Common.Interfaces;
using AeroTravel.Domain.Entities;
using AeroTravel.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace AeroTravel.Tests.Common;

public static class TestDb
{
    public static AppDbContext Create()
    {
        var options = new DbContextOptionsBuilder<AppDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString())
            .Options;
        return new AppDbContext(options);
    }
}

public class FakePasswordHasher : IPasswordHasher
{
    public string Hash(string password) => $"hashed:{password}";
    public bool Verify(string password, string hash) => hash == $"hashed:{password}";
}

public class FakeJwtTokenGenerator : IJwtTokenGenerator
{
    public (string token, DateTime expiresAtUtc) GenerateAccessToken(AdminUser user) => ("fake-access-token", DateTime.UtcNow.AddMinutes(15));
    public string GenerateRefreshTokenValue() => Guid.NewGuid().ToString("n");
    public string HashRefreshTokenValue(string rawValue) => $"hash:{rawValue}";
}

public class FakeCurrentUserService(Guid? adminUserId = null) : ICurrentUserService
{
    public Guid? AdminUserId { get; } = adminUserId;
    public string? IpAddress => "127.0.0.1";
}
